extern "C" {
	#include "openplc.h"
}