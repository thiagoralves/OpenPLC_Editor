# -*- coding: utf-8 -*-

# See COPYING.Runtime file for copyrights details.


def _(x):
    """No translation"""
    return x


Broken = _("Broken")
Started = _("Started")
Stopped = _("Stopped")
Disconnected = _("Disconnected")
Empty = _("Empty")
